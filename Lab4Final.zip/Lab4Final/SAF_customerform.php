<?php include('includes/inc_header.php'); ?>

    <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h4 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase font-weight-bold">Contact Us</h4>
            <div class="d-inline-flex">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">Registration Form</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

	
<form method="POST" action="Lab/SamFord/SAF_customerform.php" >
<table align="center" cellpadding = "10">
 
<!----- First Name ---------------------------------------------------------->
<tr>
<td>First Name</td>
<td><input type="text" name="firstname" maxlength="35" required />
</td>
</tr>

<!----- Last Name ---------------------------------------------------------->
<tr>
<td>Last Name</td>
<td><input type="text" name="lastname" maxlength="35" required />
</td>
</tr>
 
<!----- Address ---------------------------------------------------------->
<tr>
<td>Address <br /><br /><br /></td>
<td><textarea name="address" rows="3" cols="30" maxlength="35" ></textarea></td>
</tr>
 
<!----- City ---------------------------------------------------------->
<tr>
<td>City</td>
<td><input type="text" name="city" maxlength="35" />
</td>
</tr>
 
<!----- Zip Code ---------------------------------------------------------->
<tr>
<td>Zip Code</td>
<td><input type="text" name="Zip Code" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="5" />
</td>
</tr>
 
<!----- State ---------------------------------------------------------->
<tr>
<td>State</td>
<td><input type="text" name="state" pattern="[a-zA-Z'-'\s]*" maxlength="2" />
</td>
</tr>
 
<!----- Email Id ---------------------------------------------------------->
<tr>
<td>Email</td>
<td><input type="email" name="email" maxlength="35" required /></td>
</tr>
 
<!----- Mobile Number ---------------------------------------------------------->
<tr>
<td>Phone Number</td>
<td>
<input type="text" name="mobile" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="15" required />
</td>
</tr>

<!----- Contact preference choices ----------------------------------------------------------->
<tr>
<td>Contact preference</td>
<td>
Email <input type="radio" name="Email" value="Email" />
Phone <input type="radio" name="Phone" value="Phone" />
</td>
</tr>

<!----- Date Of Birth -------------------------------------------------------->
<tr>
<td>Birthdate</td>
<td><input type="date" name="birthdate" /></td>
</tr>

<!----- Comments ---------------------------------------------------------->
<tr>
<td>Comments <br /><br /><br /></td>
<td><textarea name="Comments" rows="4" cols="30" maxlength="250" ></textarea></td>
</tr>

<!----- Terms and Conditions ------------------------------------------------->
<td colspan="2" align="center">
<input type="checkbox" name="checkbox" value="check" id="agree" required />
The customer is over 18 years of age.
<br>
<br>
	
<!----- Submit and Reset ------------------------------------------------->
<input type="submit" name="submit" value="Submit">
<input type="reset" value="Clear">
</td>
</tr>
</table>
 
</form>

<?php include('includes/inc_footer.php'); ?>