<?php
include_once 'Lab/SamFord/connect.php';
if(isset($_POST['submit']))
{    
     $fname = $_POST['firstname'];
	 $lname = $_POST['lastname'];
     $email = $_POST['email'];
     $mobile = $_POST['mobile'];
     $sql = "INSERT INTO customer_list (firstname,lastname,email,mobile)
     VALUES ('$name','$email','$mobile')";
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>