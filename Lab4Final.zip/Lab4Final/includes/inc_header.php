<!DOCTYPE html>
<html lang="en">
	<!--
	Name: Le An Dang
	Class: INEW-2434
	Date: 3/10/2022
	File name: header.php
	-->
<head>
    <meta charset="utf-8">
    <title>Homepage - Sam Allen Ford</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/samford.css" rel="stylesheet">
	
	 <!-- Favicon -->
<?php include('inc_nav.php'); ?>
    <!-- Navbar End -->
</head>