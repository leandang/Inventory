    <!-- Favicon -->
    <link href="img/ford.ico" rel="icon">    <!-- Navbar Start -->
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-md bg-none navbar-dark py-2">
            <a href="" class="navbar-brand">
                <h1 class="m-3 display-5 font-weight-bold text-uppercase text-white"><img src="img/logo/Sam-Allen-Ford.jpeg" alt="Logo" width="120" height="90"></h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-0 bg-dark">
                    <a href="index.php?page=home_page" class="nav-item nav-link">Home</a>
					<!-- Insert the code to convert the button images to hyperlinks 
					<a href = "index.php?page=home_page">
					<img class="btn" src="Images/ButtonHomePage.gif" 
					alt="[Home Page]" title="Home Page"style = 
					"border:0" /></a><br />
					-->
					
					<div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Cars</a>
						<div class="dropdown-menu text-capitalize">
                            <a href="" class="dropdown-item">Maverick</a>
                            <a href="" class="dropdown-item">Mustang</a>
							<a href="" class="dropdown-item">Truck F-150</a>
                            <a href="" class="dropdown-item">Ranger</a>
                        </div>
					</div>

                    <a href="parts.php" class="nav-item nav-link">Parts</a>
                    <a href="service.php" class="nav-item nav-link">Service</a>
					<a href="about.php" class="nav-item nav-link">About Us</a>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->