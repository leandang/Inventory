<?php
    $servername='localhost:81';
    $username='root';
    $password='';
    $dbname = 'customer_list';
    $conn=mysqli_connect($servername,$username,$password,$dbname);
      if(!$conn){
          die 'Could not Connect MySql Server:' .mysql_error();
        }
?>